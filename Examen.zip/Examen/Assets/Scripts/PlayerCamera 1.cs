using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerCamera : MonoBehaviour
{
    public Transform playerBody;
    public float sensitivity = 1000f;

    private float xRotation;
    private bool isMobile;

    void Start()
    {
        isMobile = Application.isMobilePlatform;
        Cursor.lockState = CursorLockMode.Locked;
    }

    void Update()
    {
        float mouseX = 0f, mouseY = 0f;

        if (!isMobile)
        {
            mouseX = Input.GetAxis("Mouse X") * sensitivity * Time.deltaTime;
            mouseY = Input.GetAxis("Mouse Y") * sensitivity * Time.deltaTime;
        }
        else
        {
            float dx = 0f, dy = 0f;
            for (int i = 0; i < Input.touchCount; i++)
            {
                Touch t = Input.GetTouch(i);
                if (t.position.x > Screen.width * 0.5f)
                {
                    dx += t.deltaPosition.x;
                    dy += t.deltaPosition.y;
                }
            }
            mouseX = dx * sensitivity * Time.deltaTime;
            mouseY = dy * sensitivity * Time.deltaTime;
        }

        xRotation -= mouseY;
        xRotation = Mathf.Clamp(xRotation, -90f, 90f);
        transform.localRotation = Quaternion.Euler(xRotation, 0f, 0f);
        playerBody.Rotate(Vector3.up * mouseX);
    }
}

