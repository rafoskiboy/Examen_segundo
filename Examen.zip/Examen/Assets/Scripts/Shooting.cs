using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shooting : MonoBehaviour
{
    [Header("Referencias")]
    public Transform firePoint;
    public BulletPool bulletPool;

    [Header("Disparo")]
    public float fireRate = 0.18f;
    public KeyCode shootKey = KeyCode.Mouse0;

    private float nextFireTime;
    private bool isMobile;

    void Start()
    {
        isMobile = Application.isMobilePlatform;
    }

    void Update()
    {
        bool shootInput = !isMobile ? Input.GetKey(shootKey) : false;

        if (isMobile)
        {
            for (int i = 0; i < Input.touchCount; i++)
            {
                if (Input.GetTouch(i).position.x > Screen.width * 0.5f)
                {
                    shootInput = true;
                    break;
                }
            }
        }

        if (shootInput && Time.time >= nextFireTime)
        {
            nextFireTime = Time.time + fireRate;
            Shoot();
        }
    }

    void Shoot()
    {
        GameObject bullet = bulletPool.GetBullet();
        bullet.transform.SetPositionAndRotation(firePoint.position, firePoint.rotation);
        bullet.SetActive(true);
    }
}

