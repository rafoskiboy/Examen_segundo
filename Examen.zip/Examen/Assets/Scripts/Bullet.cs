using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    public float speed = 20f;
    public float lifeTime = 3f;
    public int damage = 20;
    private float timer;

    void OnEnable()
    {
        timer = 0f; 
    }

    // Update is called once per frame
    void Update()
    {
        transform.Translate(Vector3.forward * speed * Time.deltaTime);

        timer += Time.deltaTime;
        if(timer>= lifeTime) 
        {
            gameObject.SetActive(false);
        }

    }

   
}
