using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(CharacterController))]

public class PlayerController : MonoBehaviour
{
    public float walkSpeed = 5f;
    public float runSpeed = 10f;
    public float jumpForce = 0.03f;
    public float gravity = 0.11f;

    [Header("Android")] public float touchSensitivity = 0.15f;
    private CharacterController cc;

    private float yVelocity;
    private bool isMobile;

    void Start()
    {
        cc = GetComponent<CharacterController>();
        isMobile = Application.isMobilePlatform;
    }

    // Update is called once per frame
    void Update()
    {
        float x = Input.GetAxis("Horizontal");
        float z = Input.GetAxis("Vertical");

        if(isMobile && Input.touchCount > 0) 
        {
            Touch touch = Input.GetTouch(0);

            if(touch.position.x<Screen.width * 0.5f) 
            {
                x = Mathf.Clamp(touch.deltaPosition.x * touchSensitivity, -1f, 1f);
                z = Mathf.Clamp(touch.deltaPosition.y * touchSensitivity, -1f, 1f);
            }
        }

        float mag = Mathf.Sqrt(x * x + z * z);

        float currentSpeed = isMobile ? (mag > 0.7f ? runSpeed : walkSpeed) : (Input.GetKey(KeyCode.LeftShift) ? runSpeed : walkSpeed);

        Vector3 move = (transform.right * x + transform.forward * z).normalized * currentSpeed * Time.deltaTime;

        bool jumpInput = Input.GetButtonDown("Jump");
        
        if(isMobile)
            for (int i = 0; i < Input.touchCount; i++) 
            {
                Touch t = Input.GetTouch(i);

                if (t.phase == TouchPhase.Began && t.position.x>Screen.width * 0.5f && t.position.y<Screen.height * 0.3f) 
                {
                    jumpInput = true;
                    break;
                }
            }

        if (jumpInput && cc.isGrounded) yVelocity = jumpForce;
        yVelocity -= gravity * Time.deltaTime;

        move.y = yVelocity;
        cc.Move(move);
    }
}
