using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletPool : MonoBehaviour
{
    public GameObject bulletPrefab;
    public int initialSize = 20;
    private List<GameObject> pool = new List<GameObject>();

    void Start()
    {
       for (int i = 0; i< initialSize; i++) 
       {
            CreateBullet();   
       }    
    }

    GameObject CreateBullet() 
    {
        GameObject bullet = Instantiate(bulletPrefab);
        bullet.SetActive(false);
        bullet.transform.SetParent(transform);

        pool.Add(bullet);
        return bullet;
    }

    public GameObject GetBullet() 
    {
       foreach (var bullet in pool) 
       {
            if (!bullet.activeInHierarchy)
                return bullet;
       }

        return CreateBullet();
    }

    
}
