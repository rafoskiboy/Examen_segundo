using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyHealth : MonoBehaviour
{
    [SerializeField] int hitsToDestroy = 3;  // Cambia desde Inspector
    int currentHits;

    public void TakeHit()
    {
        if (++currentHits >= hitsToDestroy)
            Destroy(gameObject);
    }
}

